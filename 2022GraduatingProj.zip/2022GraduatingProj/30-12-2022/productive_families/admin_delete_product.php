<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">Delete Product</h1>

<?php
// delete the product
mysql_query ( "DELETE FROM product WHERE id = $_GET[id]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysql_affected_rows () == 1) {
	echo "<script>alert('successfully deleted ');</script>";
	
	header ( "REFRESH:0; url=admin_manage_products.php" );
} else {
	echo "<script>alert('Error While Delete');</script>";
	header ( "REFRESH:0; url=admin_manage_products.php" );
}
?>

<?php include 'footer.php';?>