<?php require 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">All Categories</h1>

<?php
// get category details
$category = mysql_query ( "SELECT * FROM category" );
?>
<br />
<div class="table-responsive">
	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		<tr>
			<th>Name</th>
			<th>Action</th>
		</tr>

	<?php while ($category_row = mysql_fetch_array ( $category)) {?>
		<tr>
			<td><?php echo $category_row['name'];?></td>
			<td>
				<a href="admin_edit_category.php?id=<?php echo $category_row['id'];?>">Edit</a> | 
				<a href="admin_delete_category.php?id=<?php echo $category_row['id'];?>">Delete</a>
			</td>
		</tr>
	<?php }?>
		<tr>
			<td align="center" colspan="2"><a href="admin_add_category.php">Add Category</a></td>
		</tr>
	</table>
</div>

<br />
<?php require 'footer.php'; ?>