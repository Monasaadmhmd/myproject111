<?php include 'header.php'; ?>

<h1 class="h3 mb-4 text-gray-800" align="center">Edit Profile</h1>

<?php
// if there is post from the user to edit the profile
if (isset ( $_POST ['submit'] )) {
	$first_name = $_POST ['first_name'];
	$last_name = $_POST ['last_name'];
	$username = $_POST ['username'];
	$password = $_POST ['password'];
	$email = $_POST ['email'];
	$mobile = $_POST ['mobile'];
	
	$update_query = "UPDATE $_SESSION[user_type] 
							SET first_name = '$first_name', last_name = '$last_name', username = '$username', password = '$password', email = '$email', mobile = '$mobile' 
							WHERE id = $_SESSION[user_id]";
	
	//echo $update_query;
	
	$update_member_result = mysql_query ( $update_query ) or die ( "Can't update this member" . mysql_error () );
	
	// if there is affected rows in the database;
	if (mysql_affected_rows () == 1) {
		// set the session var for the user
		$_SESSION ['user'] = $username;
		
		echo "<h3>Thank you for edit your profile .... you will be redirected to your profile page</h3>";
		
		// redirect to the home page
		header ( "REFRESH:3; url=profile.php" );
	}
} // end if isset($_POST['edit_profile'])

else { // if there is no post to edit the profile; show the reset of the page
       // check for the user is login or not
       // if he not logged in ; redirect to the index page
	if (! isset ( $_SESSION ['user'] ) || $_SESSION ['user'] == "") {
		header ( "Location: index.php" );
	}
}
?>

<?php include 'footer.php'; ?>