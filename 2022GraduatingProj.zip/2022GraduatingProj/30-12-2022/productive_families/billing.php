<?php include 'header.php'; ?>

<style>
table th {
	text-align: left;
	background-color: #fff;
	line-height: 20px;
	padding: 5px;
}
</style>


<?php
$total = get_order_total () + 20;
?>

<?php
if ($_GET ['action'] == 'ok') {
	$address = $_POST ['address'];
	$date = date('Y-m-d');
	$result = mysql_query ( "insert into orders(customer_id, total_price, address, date) values($_SESSION[user_id], $total, '$address', '$date')" );
	
	$orderid = mysql_insert_id ();		// get order id
	$customer_id = $_SESSION['user_id'];
	
	// insert the order details
	$max = count ( $_SESSION ['cart'] );
	
	for($i = 0; $i < $max; $i ++) {
		$pid = $_SESSION ['cart'] [$i] ['productid'];
		$q = $_SESSION ['cart'] [$i] ['qty'];
		$price = get_price ( $pid );
		mysql_query ( "insert into order_details (order_id, product_id, quantity, price) values ($orderid,$pid,$q,$price)" ) or die ("Error details " . mysql_error ());
		
		// decrease quantity
		//mysql_query ( "update product set quantity = quantity - $q where id = $pid" ) or die ("Error details " . mysql_error ());
	}
	
	// destroy the sessions
	unset ($_SESSION ['cart']);
	
	echo '<script>alert("Thank You! your order has been placed!")</script>';
	header ( "REFRESH:0; url=index.php" );
}
?>


<div class="title-container">
	<div class="section-titles">
		<div class="section-title active" data-id="latest">
			<h1 class="primary-title">Billing Information</h1>
		</div>
	</div>
</div>

<br />
<div align="center">
	<h3>Thank you for choosing Our Website </h3>
	<h3>Shipping payments will be 20 SAR</h3>
	<br/>
	<br/>
	<form action="billing.php?action=ok" method="post">

		<table cellpadding="5px" cellspacing="5px" width="50%" style="background:#eee;" border="1">
			<tr>
				<th>Order Total</th>
				<td><?php echo $total - 20 ; ?> SAR Order + 20 SAR Shipping  ( <?php echo $total ; ?> SAR total)</td>
			</tr>
			<tr>
				<th>Address or Location:</th>
				<td>
					<textarea type="text" id="address"	name="address" rows=3 required="required" class="form-control"></textarea></td>
			</tr>
			<tr id="visa_name_tr" >
				<th>Card Owner Name :</th>
				<td><input type="text" name="card_owner_name" id="visa_name" class="form-control" required /></td>
			</tr>
			<tr id="visa_num_tr" >
				<th>Card Number :</th>
				<td><input type="text" name="card_number" id="visa_num" class="form-control" pattern="[0-9]{14}" required /></td>
			</tr>
			<tr id="visa_ccv_tr" >
				<th>CCV :</th>
				<td><input type="text" name="card_cvv" id="visa_ccv" class="form-control" pattern="[0-9]{3}" required /></td>
			</tr>
			<tr id="visa_date_year_tr" >
				<th>Expire Year :</th>
				<td><select id="visa_date_year" name="card_expire_year" size="1" id="">
						<option value="2023">2023</option>
						<option value="2024">2024</option>
						<option value="2025">2025</option>
						<option value="2026">2026</option>
				</select></td>
			</tr>
			<tr id="visa_date_month_tr">
				<th>Expire Month :</th>
				<td><select id="visa_date_month" name="card_expire_month" size="1" id="" class="form-control">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center"><button class="btn btn-info log-btn">Confirm</button></td>
			</tr>
		</table>
	</form>
</div>
<?php include 'footer.php'; ?>