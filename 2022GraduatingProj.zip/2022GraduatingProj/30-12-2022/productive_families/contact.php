<?php include 'header.php';?>

<h1 class="h3 mb-4 text-gray-800" align="center">Contact us</h1>

<table>
	<tr>
		<th>Email</th>
		<td>project@hotmail.com</td>
	</tr>
	<tr>
		<th>Phone</th>
		<td>009660551234567</td>
	</tr>
	<tr>
		<th>Location</th>
		<td><a href="https://maps.google.com"><span class="maps"><i class="fa fa-map-marker"></i></span></a></td>
	</tr>
</table>

<?php include 'footer.php';?>