<?php include 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index psize
if ($_SESSION ['user_id'] == "") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">Edit Profile</h1>

	<?php
	// if the user is loggedin
	$query = "SELECT * FROM $_SESSION[user_type] WHERE id = $_SESSION[user_id]";
	$member_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );
	
	$member_row = mysql_fetch_array ( $member_result );
	
	if (mysql_num_rows ( $member_result ) == 1) {
		?>
<form action="profile_edit_test.php" method="post">
	<table align="center" width="100%">
		<tr>
			<td><strong>First Name</strong></td>
			<td><input type="text" name="first_name"
				value="<?php echo $member_row['first_name'];?>" required 
				class="form-control"></td>
		</tr>
		<tr>
			<td><strong>Last Name</strong></td>
			<td><input type="text" name="last_name"
				value="<?php echo $member_row['last_name'];?>" required 
				class="form-control"></td>
		</tr>
		<tr>
			<td><strong>User Name</strong></td>
			<td><input type="text" name="username" class="form-control" required
				value="<?php echo $member_row['username'];?>"></td>
		</tr>
		<tr>
			<td><strong>Email</strong></td>
			<td><input type="email" name="email" class="form-control" required
				value="<?php echo $member_row['email'];?>"></td>
		</tr>
		<tr>
			<td><strong>Password</strong></td>
			<td><input type="password" name="password" class="form-control" required
				value="<?php echo $member_row['password'];?>"></td>
		</tr>
		<tr>
			<td><strong>Mobile</strong></td>
			<td><input type="text" name="mobile" class="form-control"
				value="<?php echo $member_row['mobile'];?>" pattern="[0-9]{10}"></td>
		</tr>
		<tr>
			<td align="center" colspan="2"><input type="submit"
				class="btn btn-info" value="Edit Profile" name="submit"></td>
		</tr>
	</table>
</form>
<?php
	} // end if the num_rows($member_result);
	?>

<?php include 'footer.php'; ?>