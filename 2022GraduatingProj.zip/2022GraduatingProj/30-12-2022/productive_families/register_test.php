<?php include 'header.php';?>

<h1 class="h3 mb-4 text-gray-800" align="center">Register</h1>

<?php
if (isset ( $_POST ['username'] )) {
	// user vars
	$first_name = $_POST ['first_name'];
	$last_name = $_POST ['last_name'];
	$username = $_POST ['username'];
	$password = $_POST ['password'];
	$email = $_POST ['email'];
	$mobile = $_POST ['mobile'];
	$type = $_POST ['type'];
	
	// query to check if the user has registerd before or not
	$username_query = mysql_query ( "SELECT username FROM $type WHERE username = '$username' OR email = '$email' OR mobile = '$mobile'" ) or die ( 'error ' . mysql_error () );
	
	if (mysql_num_rows ( $username_query ) != 0) {
		echo "<h3 style='text-align: center; padding-bottom: 10px; border-bottom: 1px solid #d9db5c'>This username or email has already registered before.... try another one</h3>";
	} else {
		// insert query for user
		$query = "INSERT INTO $type
		(first_name, last_name, username, password, email, mobile)
		VALUES
		('$first_name', '$last_name', '$username', '$password', '$email', '$mobile')";
		
		//echo $query;
		
		$user_result = mysql_query ( $query ) or die ( "Can't add this member" . mysql_error () );
		
		// if there is affected rows in the database;
		if (mysql_affected_rows () == 1) {
			echo "<h3>You have been Registerd successfuly</h3>";
			// redirect to the home page
			header ( "REFRESH:3; url=index.php" );
		} else {
			echo "<h3>Error in register</h3>";
			// redirect to the home page
			header ( "REFRESH:3; url=index.php" );
		}
	}
}
?>

<?php include 'footer.php';?>