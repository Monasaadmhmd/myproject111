<?php include 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index psize
if ($_SESSION ['user_id'] == "") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">Your Profile</h1>

<?php
// if the user is loggedin
$query = "SELECT * FROM $_SESSION[user_type] WHERE id = $_SESSION[user_id]";
$member_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$member_row = mysql_fetch_array ( $member_result );

if (mysql_num_rows ( $member_result ) == 1) {
	?>
<table width="100%" align="center">
	<tr>
		<td><strong>First Name</strong></td>
		<td><input type="text" name="first_name"
			value="<?php echo $member_row['first_name'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td><strong>Last Name</strong></td>
		<td><input type="text" name="last_name"
			value="<?php echo $member_row['last_name'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td><strong>User Name</strong></td>
		<td><input type="text" name="username"
			value="<?php echo $member_row['username'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td><strong>Email</strong></td>
		<td><input type="text" name="email"
			value="<?php echo $member_row['email'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td><strong>Password</strong></td>
		<td><input type="text" name="password"
			value="<?php echo $member_row['password'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td><strong>Mobile</strong></td>
		<td><input type="text" name="mobile"
			value="<?php echo $member_row['mobile'];?>" disabled="disabled"
			class="form-control"></td>
	</tr>
	<tr>
		<td align="center" colspan="2"><a href="profile_edit.php">Edit Your Profile</a></td>
	</tr>
</table>
<?php
} // end if the num_rows($member_result);
?>

<?php include 'footer.php'; ?>