<?php include 'header.php';?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die();
}
?>

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Edit Category</h1>

<?php
$category = mysql_query ( "SELECT * FROM category WHERE id = $_GET[id]" ) or die ( "error category " . mysql_error () );
$category_row = mysql_fetch_array ( $category );
?>

<div class="row">
	<div class="col-lg-12">
			<?php
			if (isset ( $_POST ['name'] )) {
				$name = $_POST ['name'];
				
				$query = "UPDATE category SET name = '$name' WHERE id = $_GET[id]";
				$result = mysql_query ( $query ) or die ( "Error register " . mysql_error () );
				
				if (mysql_affected_rows () == 1) {
					echo "<div class='alert alert-success'>
								<span><h4>Successfully update</h4></span>
						  </div>";
				} else {
					echo "<div class='alert alert-danger'>
								<span><h4>Error in update </h4></span>
						  </div>";
				}
				
				header ( "REFRESH:3; url=admin_manage_categories.php" );
			} else {
				?>
			<form class="user" method="post"  enctype="multipart/form-data" 
				id="register_form" name="register_form">
				<table align="center" width="100%">
					<tr>
						<th>Name</th>
						<td><input type="text" class="form-control " name="name"
							value="<?php echo $category_row['name'];?>" /></td>
					</tr>
					<tr>
						<td><br /></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input type="submit" name="submit" value="Update" 
							class="btn btn-primary btn-user btn-block" /></td>
					</tr>
				</table>
			</form>
		<?php } // end of else there is no submit?>
	</div>
</div>

<?php include 'footer.php';?>