<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user'] != "") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">Register</h1>

<form action="register_test.php" method="post">

	<table align="center" width="100%">
		<tr>
			<td><strong>First Name</strong></td>
			<td><input type="text" name="first_name" id="first_name" required
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Last Name</strong></td>
			<td><input type="text" name="last_name" id="last_name" required
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Username</strong></td>
			<td><input type="text" name="username" id="username" required
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Email</strong></td>
			<td><input type="email" name="email" id="email" class="form-control"
				required value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Password</strong></td>
			<td><input type="password" name="password" id="password" required
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Mobile</strong></td>
			<td><input type="text" name="mobile" required id="mobile"
				class="form-control" value="" pattern="[0-9]{10}" size="20" /></td>
		</tr>		
		<tr>
			<td><strong>Register As </strong></td>
			<td>
				<select name="type" class="form-control">
					<option value="customer">Customer</option>
					<option value="family">Productive Family</option>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="wp-submit"
				class="btn btn-info" id="wp-submit" value="Register" /></td>
		</tr>
	</table>
</form>
<?php include 'footer.php';?>