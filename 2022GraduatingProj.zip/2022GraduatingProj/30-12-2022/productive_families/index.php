<?php include 'main_header.php'; ?>

<?php
if ($_REQUEST ['command'] == 'add' && $_REQUEST ['productid'] > 0) {
	// echo "test";
	$pid = $_REQUEST ['productid'];
	addtocart ( $pid, 1 );
	// header ( "Location:shopping_cart.php" );
	// echo "<script>location.href = 'Location:shopping_cart.php.php';</script>";
	// exit ();
	
	echo '<meta http-equiv="refresh" content="1; url=shopping_cart.php">';
}
?>

<script language="javascript">
	function addtocart(pid){
		document.form1.productid.value=pid;
		document.form1.command.value='add';
		document.form1.submit();
	}
</script>

<form name="form1">
	<input type="hidden" name="productid" /> 
	<input type="hidden" name="command" />
</form>

<?php
$query = "SELECT * FROM product LIMIT 6";
$products = mysql_query ( $query ) or die ( mysql_error () );
?>


<!-- Start Most Popular -->
<div class="product-area most-popular section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title">
					<h2>Latest Products</h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="owl-carousel popular-slider">
					<?php while ( $product = mysql_fetch_array ( $products ) ) {?>
					<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="show_product_details.php?id=<?php echo $product['id']?>">
									<img class="default-img" src="products/<?php echo $product['img']?>" width="150" height="200" alt="#">
									<img class="hover-img" src="products/<?php echo $product['img']?>" width="150" height="200" alt="#">
								</a>
								<?php if ($_SESSION['user_type'] == "customer") { ?>
									<div class="button-head">
										<div class="product-action-2">
											<a title="Add to cart" href="#" onclick="addtocart(<?php echo $product['id']?>)">Add to cart</a>
										</div>
									</div>
								<?php }?>
							</div>
							<div class="product-content">
								<h3><a href="show_product_details.php?id=<?php echo $product['id']?>"><?php echo $product['name']?></a></h3>
								<div class="product-price">
									<span><?php echo $product['price']?> SAR</span>
								</div>
							</div>
						</div>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Most Popular Area -->

<!-- Start Shop Services Area -->
<section class="shop-services section home">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="ti-rocket"></i>
					<h4>Free shiping</h4>
					<p>Orders over 100 SAR</p>
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-3 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="ti-reload"></i>
					<h4>Free Return</h4>
					<p>Within 30 days returns</p>
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-3 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="ti-lock"></i>
					<h4>Sucure Payment</h4>
					<p>100% secure payment</p>
				</div>
				<!-- End Single Service -->
			</div>
			<div class="col-lg-3 col-md-6 col-12">
				<!-- Start Single Service -->
				<div class="single-service">
					<i class="ti-tag"></i>
					<h4>Best Peice</h4>
					<p>Guaranteed price</p>
				</div>
				<!-- End Single Service -->
			</div>
		</div>
	</div>
</section>
<br/>
<!-- End Shop Services Area -->
	
<?php include 'main_footer.php'; ?>