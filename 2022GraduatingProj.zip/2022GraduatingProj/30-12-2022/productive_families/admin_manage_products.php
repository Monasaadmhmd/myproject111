<?php require 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">All Products</h1>

<?php
// get product details
$product = mysql_query ( "SELECT product.*, product.id AS product_id, CONCAT (family.first_name, ' ', family.last_name) AS family_name, category.name AS category_name 
FROM product 
LEFT JOIN family ON product.family_id = family.id 
LEFT JOIN category ON product.cat_id = category.id" );
?>
<br />
<div class="table-responsive">
	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		<tr>
			<th>Image</th>
			<th>Family</th>
			<th>Name</th>
			<th>Description</th>
			<th>Price</th>
			<th>Category</th>
			<th>Action</th>
		</tr>

	<?php while ($product_row = mysql_fetch_array ( $product)) {?>
		<tr>
			<td><img src="products/<?php echo $product_row['img'];?>" width="100" height="100" /></td>
			<td><?php echo $product_row['family_name'];?></td>
			<td><?php echo $product_row['name'];?></td>
			<td><?php echo $product_row['description'];?></td>
			<td><?php echo $product_row['price'];?> SAR</td>
			<td><?php echo $product_row['category_name'];?></td>
			<td>
				<a href="admin_delete_product.php?id=<?php echo $product_row['product_id'];?>">Delete</a>
			</td>
		</tr>
	<?php }?>
	</table>
</div>

<br />
<?php require 'footer.php'; ?>