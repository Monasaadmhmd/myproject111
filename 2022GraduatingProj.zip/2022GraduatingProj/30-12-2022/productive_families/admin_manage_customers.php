<?php require 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">All Customers</h1>

<?php
// get customer details
$customer = mysql_query ( "SELECT * FROM customer" );
?>

<div class="table-responsive">
	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>User Name</th>
			<th>Email</th>
			<th>Mobile</th>
			<th>Action</th>
		</tr>

	<?php while ($customer_row = mysql_fetch_array ( $customer )) {?>
		<tr>
			<td><?php echo $customer_row['first_name'];?></td>
			<td><?php echo $customer_row['last_name'];?></td>
			<td><?php echo $customer_row['username'];?></td>
			<td><?php echo $customer_row['email'];?></td>
			<td><?php echo $customer_row['mobile'];?></td>
			<td>
				<a href="admin_delete_customer.php?id=<?php echo $customer_row['id'];?>">Delete</a>
			</td>
		</tr>
	<?php }?>
	</table>
</div>
<br />
<br />
<?php require 'footer.php'; ?>