<?php include 'header.php';?>

<?php
// if the user is logged in; redirect to the home page
if (isset ( $_SESSION ['user'] ) || $_SESSION ['user'] != "") {
	header ( "Location: index.php" );
}
?>

<h1 class="h3 mb-4 text-gray-800" align="center">Login</h1>

<?php
if (isset ( $_POST ['username'] ) && isset ( $_POST ['password'] )) {
	$username = $_POST ['username'];
	$password = $_POST ['password'];
	
	$query = "SELECT * FROM customer WHERE username = '$username' AND password = '$password'";
	
	$user_result = mysql_query ( $query ) or die ( "cant get username and password from the user" . mysql_error () );
	$user_row = mysql_fetch_array ( $user_result );
	
	// if we find the username
	if (mysql_num_rows ( $user_result ) == 1) {
		// set the session var for the user
		$_SESSION ['user'] = $user_row ['username'];
		$_SESSION ['user_id'] = $user_row ['id'];
		$_SESSION ['user_type'] = "customer";
		
		// show successful mesg to the user
		echo "<h3>You have been logged in.... you will be redirected to the home page</h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3; url=index.php" />';
	} else {
			$query = "SELECT * FROM family WHERE username = '$username' AND password = '$password'";
	
			$user_result = mysql_query ( $query ) or die ( "cant get username and password from the user" . mysql_error () );
			$user_row = mysql_fetch_array ( $user_result );
			
			// if we find the username
			if (mysql_num_rows ( $user_result ) == 1) {
				// set the session var for the user
				$_SESSION ['user'] = $user_row ['username'];
				$_SESSION ['user_id'] = $user_row ['id'];
				$_SESSION ['user_type'] = "family";
				
				// show successful mesg to the user
				echo "<h3>You have been logged in.... you will be redirected to the home page</h3>";
				
				// redirect to the home page
				echo '<meta http-equiv="refresh" content="3; url=index.php" />';
			} else {
				$query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
	
				$user_result = mysql_query ( $query ) or die ( "cant get username and password from the user" . mysql_error () );
				$user_row = mysql_fetch_array ( $user_result );
				
				// if we find the username
				if (mysql_num_rows ( $user_result ) == 1) {
					// set the session var for the user
					$_SESSION ['user'] = $user_row ['username'];
					$_SESSION ['user_id'] = $user_row ['id'];
					$_SESSION ['user_type'] = "admin";
					
					// show successful mesg to the user
					echo "<h3>You have been logged in.... you will be redirected to the home page</h3>";
					
					// redirect to the home page
					echo '<meta http-equiv="refresh" content="3; url=index.php" />';
				} else {
					// show error message to the user
					echo "<script>alert('Invalid username or password');</script>";
					echo '<meta http-equiv="refresh" content="0; url=index.php" />';
				}
			}
	}
} else {
	?>

<form name="loginform" id="loginform" method="post">
	<table align="center" width="100%">
		<tr>
			<td><strong>Username</strong></td>
			<td><input type="text" name="username" id="username"
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td><strong>Password</strong></td>
			<td><input type="password" name="password" id="password"
				class="form-control" value="" size="20" /></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="wp-submit"
				class="btn btn-info" id="wp-submit" value="Login" /></td>
		</tr>

	</table>
</form>

<?php } ?>

<?php include 'footer.php';?>