<?php
// start the session
session_start ();

// destroy the sessions
session_destroy ();

// redirect to the index.php
echo '<meta http-equiv="refresh" content="0; url=index.php" />';

?>